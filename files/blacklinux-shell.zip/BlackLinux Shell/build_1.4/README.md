# Blacklinux v1.4 LTS - Whats new

=> Name wurde geändert  
=> Webseite wurde überarbeitet  
=> Webseiten favicon  
=> Neues Logo  
=> v1.4  
=> Programme werden in Python nun geschrieben  
=> LTS Release  
=> Ubuntu 20.04 Basis  
=> Xad build-0.45.2  
=> neues ASCII Logo im neofetch  
=> Neue Fonts  
=> Erneurte Namensüberarbeitung am 27.05.2021 (von BlackLinux zu Blacklinux)  
