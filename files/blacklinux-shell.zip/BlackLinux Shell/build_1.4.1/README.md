# Blacklinux v1.4.1 Extended & Rolling - Whats new

=> Xad wurde geupdated
=> Based-System wurde zu Debian 10/11 geändert
=> Rolling Release Variante wurde veröffentlicht
- Immer Aktuelle Pakete
=> LTS wurde aktualisiert