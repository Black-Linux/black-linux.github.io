# Blacklinux v1.4.2 Rolling - Whats new

=> Patter wurde zum System hinzugefügt
=> Based System ist nun Debian GNU/Linux 11
