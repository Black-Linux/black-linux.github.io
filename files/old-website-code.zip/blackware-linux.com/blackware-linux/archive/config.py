def __config__{
    script "json"{
        "archive-savefile": "*.archv",
        "site-index": "archive.html"
    }
}